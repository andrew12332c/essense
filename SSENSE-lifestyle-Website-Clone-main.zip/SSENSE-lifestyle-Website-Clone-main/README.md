<html>
  <h1>SSENSE-lifestyle Website Clone</h1>
  <h3>In the Masai School Construct week project ,We have cloned the SSENSE-lifestyle website https://astounding-liger-97ffc4.netlify.app  .Sense is a shopping website that has emerging designers and streetwear brands for both men and women with global shipping.
    <br>  We built it in 5days with the team of 4 collaborators.</p>
   <p> Some features of our Projects-</p>
  <p> 1)A secure developers panel for Controlling Website,watching details and user's feedbacks for website.
    <br>2)Login/sign-up.
    <br>3)Location-based delivery.
    <br>4)Whishlist and Shopping bag.
    <br>5)Website Contact Section.
    <br>6)User friendly easy and secure payment System.
    <br>7)Return Policy if the user get damaged product.</p>
  <p>Language used :</P
  <p><ul><li>HTML-HyperText Markup Language</li>
  <li>CSS - Cascading Style Sheets</li>
  <li>JavaScript</li></ul><p>
  <h2>Sneak Peak<h2>
  <h3>Landing Page</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639409-0a707e82-88b3-40fd-aded-f0d5a059db98.png"/>
      <hr>
  <img src="https://user-images.githubusercontent.com/101391413/180639442-50782dce-927a-4430-97fd-29e620bc0e5c.png"/>
  <hr>
  <img src="https://user-images.githubusercontent.com/101391413/180639469-36ba1b59-510c-47d7-8723-bfcbe53ab408.png"/>
    <hr>
  <h3>Sign-up/login</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639639-5798aafc-059a-48ae-ab0a-73de81eb6ef1.png"/>
  <img src="https://user-images.githubusercontent.com/101391413/180639663-36be2876-8981-4a76-90bf-06c3b9b39eed.png"/>
    <hr>
  <h3>Women's Page</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639783-f484cbb3-0e5e-4d3e-aeab-1913138d0978.png"/>
    <hr>
  <h3>Men's Page</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639816-99a90047-7860-4a4b-b165-5047ed6f192e.png"/>
    <hr>
    //
  <h3>Bags Page</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639841-c67aab55-7699-4b87-ad77-966c91e6039e.png"/>
    <hr>
  <h3>Accessories Page</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639874-3c246e45-dd8b-4c1a-b8d4-bff52fb65511.png"/>
    <hr>
  <h3>Whishlist</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639909-663b611d-c571-40c4-b9cf-773597c1e667.png"/>
    <hr>
  <h3>Shopping Bag</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639955-df6fef6b-c2d8-45ad-a4cb-13ae6f34b943.png"/>
    <hr>
  <h3>Checkout Section</h3>
  <img src="https://user-images.githubusercontent.com/101391413/180639982-3d4c94a1-f5fb-4926-97fd-a15c692f8575.png"/>  
  <img src="https://user-images.githubusercontent.com/101391413/180640006-fca9006a-d7d1-4e3b-ab5b-2e99eeeeb0e6.png"/>
    <hr>
  <h2>Team Members and Contributors</h2>
  
  <h4>Ayesha Khan</h4>
    <ul><li>Github:AyeshaKhan14</li>
      <li>Github Link:https://github.com/AyeshaKhan14</li>
      <li>Email:ayeshatravels9@gmail.com</li>
      <li>LinkedIn:https://www.linkedin.com/in/ayesha-khan-8a95691b9</li></ul>
      
      
  <h4>Omkar Lakhmani</h4>
    <ul><li>Github: lakhmani-om2099</li>
      <li>Github Link: https://github.com/lakhmani-om2099</li>
      <li>Email: lakhmani.om2099@gmail.com</li>
      <li>LinkedIn: www.linkedin.com/in/omkar-lakhmani</li></ul>

  <h4>Harshal Apsunde</h4>
    <ul><li>Github: HARSHAL-AP</li>
      <li>Github Link: https://https://github.com/HARSHAL-AP</li>
      <li>Email: apsundeharshal129@gmail.com</li>
      <li>LinkedIn: https://www.linkedin.com/in/harshal-apsunde-42b40b236</li></ul>
  </html>
